#include "sum.h"

namespace library 
{

    int sum(const int a, const int b) {
        return a + b;
    }

    double sum(const double a, const double b) {
        return a + b;
    }

} // namespace library
